from simulation_runner import SimulationRunner


if __name__ == "__main__":
    runner = SimulationRunner()
    runner.run()
